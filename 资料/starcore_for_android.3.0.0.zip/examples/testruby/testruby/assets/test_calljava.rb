puts $JavaClass

val = $JavaClass.new("from ruby")
puts(val)
val.callback(1234.4564)
val.callback("sdfsdfsdfsdf")
val.SetRubyObject(File);
puts("===========end=========")